/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.gsm;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 *
 * @author s422
 */
@Entity
@Table(name = "classes_available", catalog = "classes", schema = "")
@NamedQueries({
    @NamedQuery(name = "ClassesAvailable.findAll", query = "SELECT c FROM ClassesAvailable c")
    , @NamedQuery(name = "ClassesAvailable.findByClasscode", query = "SELECT c FROM ClassesAvailable c WHERE c.classcode = :classcode")
    , @NamedQuery(name = "ClassesAvailable.findByCoursenumber", query = "SELECT c FROM ClassesAvailable c WHERE c.coursenumber = :coursenumber")
    , @NamedQuery(name = "ClassesAvailable.findByTimeStart", query = "SELECT c FROM ClassesAvailable c WHERE c.timeStart = :timeStart")
    , @NamedQuery(name = "ClassesAvailable.findByTimeFinish", query = "SELECT c FROM ClassesAvailable c WHERE c.timeFinish = :timeFinish")
    , @NamedQuery(name = "ClassesAvailable.findByDays", query = "SELECT c FROM ClassesAvailable c WHERE c.days = :days")
    , @NamedQuery(name = "ClassesAvailable.findByRoom", query = "SELECT c FROM ClassesAvailable c WHERE c.room = :room")
    , @NamedQuery(name = "ClassesAvailable.findByInstId", query = "SELECT c FROM ClassesAvailable c WHERE c.instId = :instId")})
public class ClassesAvailable implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "classcode")
    private String classcode;
    @Column(name = "coursenumber")
    private String coursenumber;
    @Column(name = "time_start")
    @Temporal(TemporalType.TIME)
    private Date timeStart;
    @Column(name = "time_finish")
    @Temporal(TemporalType.TIME)
    private Date timeFinish;
    @Basic(optional = false)
    @Column(name = "days")
    private String days;
    @Basic(optional = false)
    @Column(name = "room")
    private String room;
    @Column(name = "inst_id")
    private Integer instId;

    public ClassesAvailable() {
    }

    public ClassesAvailable(String classcode) {
        this.classcode = classcode;
    }

    public ClassesAvailable(String classcode, String days, String room) {
        this.classcode = classcode;
        this.days = days;
        this.room = room;
    }

    public String getClasscode() {
        return classcode;
    }

    public void setClasscode(String classcode) {
        String oldClasscode = this.classcode;
        this.classcode = classcode;
        changeSupport.firePropertyChange("classcode", oldClasscode, classcode);
    }

    public String getCoursenumber() {
        return coursenumber;
    }

    public void setCoursenumber(String coursenumber) {
        String oldCoursenumber = this.coursenumber;
        this.coursenumber = coursenumber;
        changeSupport.firePropertyChange("coursenumber", oldCoursenumber, coursenumber);
    }

    public Date getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(Date timeStart) {
        Date oldTimeStart = this.timeStart;
        this.timeStart = timeStart;
        changeSupport.firePropertyChange("timeStart", oldTimeStart, timeStart);
    }

    public Date getTimeFinish() {
        return timeFinish;
    }

    public void setTimeFinish(Date timeFinish) {
        Date oldTimeFinish = this.timeFinish;
        this.timeFinish = timeFinish;
        changeSupport.firePropertyChange("timeFinish", oldTimeFinish, timeFinish);
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        String oldDays = this.days;
        this.days = days;
        changeSupport.firePropertyChange("days", oldDays, days);
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        String oldRoom = this.room;
        this.room = room;
        changeSupport.firePropertyChange("room", oldRoom, room);
    }

    public Integer getInstId() {
        return instId;
    }

    public void setInstId(Integer instId) {
        Integer oldInstId = this.instId;
        this.instId = instId;
        changeSupport.firePropertyChange("instId", oldInstId, instId);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (classcode != null ? classcode.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ClassesAvailable)) {
            return false;
        }
        ClassesAvailable other = (ClassesAvailable) object;
        if ((this.classcode == null && other.classcode != null) || (this.classcode != null && !this.classcode.equals(other.classcode))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "my.gsm.ClassesAvailable[ classcode=" + classcode + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
