/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.gsm;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author s422
 */
@Entity
@Table(name = "curricula", catalog = "classes", schema = "")
@NamedQueries({
    @NamedQuery(name = "Curricula.findAll", query = "SELECT c FROM Curricula c")
    , @NamedQuery(name = "Curricula.findByCoursenumber", query = "SELECT c FROM Curricula c WHERE c.coursenumber = :coursenumber")
    , @NamedQuery(name = "Curricula.findByDestitle", query = "SELECT c FROM Curricula c WHERE c.destitle = :destitle")
    , @NamedQuery(name = "Curricula.findByStudunits", query = "SELECT c FROM Curricula c WHERE c.studunits = :studunits")
    , @NamedQuery(name = "Curricula.findByTeachunits", query = "SELECT c FROM Curricula c WHERE c.teachunits = :teachunits")})
public class Curricula implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "coursenumber")
    private String coursenumber;
    @Basic(optional = false)
    @Column(name = "destitle")
    private String destitle;
    @Basic(optional = false)
    @Column(name = "studunits")
    private int studunits;
    @Basic(optional = false)
    @Column(name = "teachunits")
    private int teachunits;

    public Curricula() {
    }

    public Curricula(String coursenumber) {
        this.coursenumber = coursenumber;
    }

    public Curricula(String coursenumber, String destitle, int studunits, int teachunits) {
        this.coursenumber = coursenumber;
        this.destitle = destitle;
        this.studunits = studunits;
        this.teachunits = teachunits;
    }

    public String getCoursenumber() {
        return coursenumber;
    }

    public void setCoursenumber(String coursenumber) {
        String oldCoursenumber = this.coursenumber;
        this.coursenumber = coursenumber;
        changeSupport.firePropertyChange("coursenumber", oldCoursenumber, coursenumber);
    }

    public String getDestitle() {
        return destitle;
    }

    public void setDestitle(String destitle) {
        String oldDestitle = this.destitle;
        this.destitle = destitle;
        changeSupport.firePropertyChange("destitle", oldDestitle, destitle);
    }

    public int getStudunits() {
        return studunits;
    }

    public void setStudunits(int studunits) {
        int oldStudunits = this.studunits;
        this.studunits = studunits;
        changeSupport.firePropertyChange("studunits", oldStudunits, studunits);
    }

    public int getTeachunits() {
        return teachunits;
    }

    public void setTeachunits(int teachunits) {
        int oldTeachunits = this.teachunits;
        this.teachunits = teachunits;
        changeSupport.firePropertyChange("teachunits", oldTeachunits, teachunits);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (coursenumber != null ? coursenumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Curricula)) {
            return false;
        }
        Curricula other = (Curricula) object;
        if ((this.coursenumber == null && other.coursenumber != null) || (this.coursenumber != null && !this.coursenumber.equals(other.coursenumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "my.gsm.Curricula[ coursenumber=" + coursenumber + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
