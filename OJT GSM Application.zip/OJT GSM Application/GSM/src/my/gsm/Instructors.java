/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.gsm;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author s422
 */
@Entity
@Table(name = "instructors", catalog = "classes", schema = "")
@NamedQueries({
    @NamedQuery(name = "Instructors.findAll", query = "SELECT i FROM Instructors i")
    , @NamedQuery(name = "Instructors.findByInstructId", query = "SELECT i FROM Instructors i WHERE i.instructId = :instructId")
    , @NamedQuery(name = "Instructors.findByInstLname", query = "SELECT i FROM Instructors i WHERE i.instLname = :instLname")
    , @NamedQuery(name = "Instructors.findByInstFname", query = "SELECT i FROM Instructors i WHERE i.instFname = :instFname")
    , @NamedQuery(name = "Instructors.findByDepartment", query = "SELECT i FROM Instructors i WHERE i.department = :department")
    , @NamedQuery(name = "Instructors.findByStatus", query = "SELECT i FROM Instructors i WHERE i.status = :status")
    , @NamedQuery(name = "Instructors.findByInstUnits", query = "SELECT i FROM Instructors i WHERE i.instUnits = :instUnits")})
public class Instructors implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "instruct_id")
    private Integer instructId;
    @Basic(optional = false)
    @Column(name = "inst_lname")
    private String instLname;
    @Basic(optional = false)
    @Column(name = "inst_fname")
    private String instFname;
    @Basic(optional = false)
    @Column(name = "department")
    private String department;
    @Basic(optional = false)
    @Column(name = "status")
    private String status;
    @Basic(optional = false)
    @Column(name = "inst_units")
    private int instUnits;

    public Instructors() {
    }

    public Instructors(Integer instructId) {
        this.instructId = instructId;
    }

    public Instructors(Integer instructId, String instLname, String instFname, String department, String status, int instUnits) {
        this.instructId = instructId;
        this.instLname = instLname;
        this.instFname = instFname;
        this.department = department;
        this.status = status;
        this.instUnits = instUnits;
    }

    public Integer getInstructId() {
        return instructId;
    }

    public void setInstructId(Integer instructId) {
        Integer oldInstructId = this.instructId;
        this.instructId = instructId;
        changeSupport.firePropertyChange("instructId", oldInstructId, instructId);
    }

    public String getInstLname() {
        return instLname;
    }

    public void setInstLname(String instLname) {
        String oldInstLname = this.instLname;
        this.instLname = instLname;
        changeSupport.firePropertyChange("instLname", oldInstLname, instLname);
    }

    public String getInstFname() {
        return instFname;
    }

    public void setInstFname(String instFname) {
        String oldInstFname = this.instFname;
        this.instFname = instFname;
        changeSupport.firePropertyChange("instFname", oldInstFname, instFname);
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        String oldDepartment = this.department;
        this.department = department;
        changeSupport.firePropertyChange("department", oldDepartment, department);
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        String oldStatus = this.status;
        this.status = status;
        changeSupport.firePropertyChange("status", oldStatus, status);
    }

    public int getInstUnits() {
        return instUnits;
    }

    public void setInstUnits(int instUnits) {
        int oldInstUnits = this.instUnits;
        this.instUnits = instUnits;
        changeSupport.firePropertyChange("instUnits", oldInstUnits, instUnits);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (instructId != null ? instructId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Instructors)) {
            return false;
        }
        Instructors other = (Instructors) object;
        if ((this.instructId == null && other.instructId != null) || (this.instructId != null && !this.instructId.equals(other.instructId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "my.gsm.Instructors[ instructId=" + instructId + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
