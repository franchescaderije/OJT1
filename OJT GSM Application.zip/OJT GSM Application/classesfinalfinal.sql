CREATE DATABASE  IF NOT EXISTS `classes` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `classes`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: classes
-- ------------------------------------------------------
-- Server version	5.7.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `classes_available`
--

DROP TABLE IF EXISTS `classes_available`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classes_available` (
  `classcode` varchar(7) NOT NULL,
  `coursenumber` varchar(7) DEFAULT NULL,
  `time_start` time DEFAULT NULL,
  `time_finish` time DEFAULT NULL,
  `days` enum('MWF','TTH','W','MTH','TF','S') NOT NULL,
  `room` enum('S326','S421','S422','S423','S425','S426','S428','S526','S527') NOT NULL,
  `inst_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`classcode`),
  UNIQUE KEY `classcode_UNIQUE` (`classcode`),
  KEY `inst_id_idx` (`inst_id`),
  KEY `coursenumber` (`coursenumber`),
  CONSTRAINT `coursenumber` FOREIGN KEY (`coursenumber`) REFERENCES `curricula` (`coursenumber`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `inst_id` FOREIGN KEY (`inst_id`) REFERENCES `instructors` (`instruct_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes_available`
--

LOCK TABLES `classes_available` WRITE;
/*!40000 ALTER TABLE `classes_available` DISABLE KEYS */;
/*!40000 ALTER TABLE `classes_available` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `curricula`
--

DROP TABLE IF EXISTS `curricula`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `curricula` (
  `coursenumber` varchar(10) NOT NULL,
  `destitle` varchar(100) NOT NULL,
  `studunits` int(1) NOT NULL,
  `teachunits` int(1) NOT NULL,
  PRIMARY KEY (`coursenumber`),
  UNIQUE KEY `coursenumber_UNIQUE` (`coursenumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `curricula`
--

LOCK TABLES `curricula` WRITE;
/*!40000 ALTER TABLE `curricula` DISABLE KEYS */;
INSERT INTO `curricula` VALUES ('CS 311A','Object Oriented Programming',3,3),('CS 311B','Compiler Design',3,3),('CS 321A','Introduction to Automata and Formal Languages',3,3),('CS 321B','Introduction to Artificial Inteligence',3,3),('CS 321D','Structure of Programming Languages',3,3),('CS 322','Methods of Research in Computer Science',3,3),('CS 422A','Modeling and Simulation Theory',3,3),('ICS 111','Introduction to Computer Science 1',2,2),('ICS 111L','Introduction to Computer Science 1',1,3),('ICS 112','Computer Programming 1',2,2),('ICS 112L','Computer Programming 1',1,3),('ICS 121','Introduction to Computer Science 2',2,2),('ICS 121L','Introduction to Computer Science 2',1,3),('ICS 122','Computer Programming 2',2,2),('ICS 122L','Computer Programming 2',1,3),('ICS 211','Data Structures with Algorithm Development',2,2),('ICS 211L','Data Structures with Algorithm Development',1,3),('ICS 212','Logic Design and Digital Computer Circuits',3,3),('ICS 221','File Organization',3,3),('ICS 222','Computer Architecture',2,2),('ICS 222L','Computer Architecture',1,3),('ICS 311','Operating Systems',2,2),('ICS 311L','Operating Systems',1,3),('ICS 312','Programming Applications',2,2),('ICS 312L','Programming Applications',1,3),('ICS 313','Discrete Mathematics',3,3),('ICS 321','Database Management Systems',2,2),('ICS 321L','Database Management Systems',1,3),('ICS 322','Data Communications and Computer Networks',2,2),('ICS 322L','Data Communications and Computer Networks',1,3),('ICS 411','Quality Conciousness, Habits and Processes',3,3),('IT 111','Information Technology Fundamentals 1',2,2),('IT 111L','Information Technology Fundamentals 1',1,3),('IT 112','Programming Fundamentals 1',2,2),('IT 112L','Programming Fundamentals 1',1,3),('IT 121','Information Technology Fundamentals 2',2,2),('IT 121L','Information Technology Fundamentals 2',1,3),('IT 122','Programming Fundamentals 2',2,2),('IT 122L','Programmming Fundamentals 2',1,3),('IT 131','Computer Architecture',2,2),('IT 131L','Computer Architecture',1,3),('IT 132','Information System Fundamentals',3,3),('IT 211','Data Structures with Algorithm Development',2,2),('IT 211L','Data Structures with Algorithm Development',1,3),('IT 221','Discrete Mathematics',3,3),('IT 222','Operating Systems',2,2),('IT 222L','Operating Systems',1,3),('IT 311','Software Modeling and Analysis',3,3),('IT 312','Programming Applications',2,2),('IT 312L','Programming Applications',1,3),('IT 315','Database Management Systems',2,2),('IT 315L','Database Management Systems',1,3),('IT 317','Financial Systems',3,3),('IT 322','Networks Technology with Administration and Maintenance',2,2),('IT 322L','Networks Technology with Administration and Maintenance',1,3),('IT 323','Integrative Programming and Technologies',2,2),('IT 323L','Integrative Programming and Technologies',1,3),('IT 324','Web Systems and Technologies',2,2),('IT 324L','Web Systems and Technologies',1,3),('IT 325N','Software Engineering Fundamentals',3,3),('IT 411','IT Project 1',3,3),('IT 413','Software Engineering',3,3),('IT 421','IT Project 2',3,3),('IT 422','Social and Professional Issues in Information Technology',3,3),('IT 423','Information Systems Planning/Information Resource Management',3,3),('IT 424','Field Trips and Seminars',3,3),('RESEARCH 1','CS Thesis 1',3,0),('RESEARCH 2','CS Thesis 2',3,0);
/*!40000 ALTER TABLE `curricula` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructors`
--

DROP TABLE IF EXISTS `instructors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instructors` (
  `instruct_id` int(11) NOT NULL AUTO_INCREMENT,
  `inst_lname` varchar(45) NOT NULL,
  `inst_fname` varchar(45) NOT NULL,
  `department` varchar(2) NOT NULL,
  `status` enum('Contractual','Regular','Provisional','Part-Time') NOT NULL,
  `inst_units` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`instruct_id`),
  UNIQUE KEY `inst_name` (`inst_lname`),
  UNIQUE KEY `inst_fname_UNIQUE` (`inst_fname`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructors`
--

LOCK TABLES `instructors` WRITE;
/*!40000 ALTER TABLE `instructors` DISABLE KEYS */;
INSERT INTO `instructors` VALUES (1,'Bacani','Benedick','IT','Regular',0),(2,'Balmeo','Laurence','IT','Part-Time',0),(3,'Clemente','Ma. Concepcion','IT','Regular',0),(4,'Domantay','Randy','IT','Regular',0),(5,'Famorca','Lambert','IT','Regular',0),(6,'Ferrer','Beverly Estephany','IT','Regular',0),(7,'Makil','Roderick','IT','Regular',0),(8,'Mangaliag','Ronald Ali','IT','Regular',0),(9,'Miguel','Dalos D.','IT','Regular',0),(10,'Montes','Carlos Ben O','IT','Regular',0),(11,'Nana','Ria Andrea','IT','Regular',0),(12,'Parra','Mark Jeffrey','IT','Part-Time',0);
/*!40000 ALTER TABLE `instructors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'classes'
--

--
-- Dumping routines for database 'classes'
--
/*!50003 DROP PROCEDURE IF EXISTS `add_class` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_class`(in ccode VARCHAR(7), in cnumber VARCHAR(7),
in time_s TIME, in time_f TIME, in daysIn ENUM('MWF','TTH','MTH','TF','W','S'), in roomselect VARCHAR(5))
BEGIN
	DECLARE classnum varchar(7);
    SELECT a.coursenumber INTO classnum FROM curricula a WHERE a.coursenumber = cnumber;
    IF EXISTS (SELECT * FROM classes_available WHERE (time_s BETWEEN time_start AND time_finish OR time_f BETWEEN time_start 
		AND time_finish) AND daysIn = days AND roomselect = room) THEN
		SIGNAL sqlstate '23400'
			SET message_text = 'Subject conflict!';
	ELSEIF (cnumber NOT IN (SELECT coursenumber FROM curricula)) THEN
		SIGNAL sqlstate '23500'
			SET message_text = 'Subject not found!';
    ELSE
		INSERT INTO classes_available (classcode, coursenumber, time_start, time_finish, days, room) values (ccode, classnum, time_s, time_f, daysIn, roomselect);
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_class_2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_class_2`(in ccode VARCHAR(7), in cnumber VARCHAR(7),
in time_s TIME, in time_f TIME, in daysIn ENUM('MWF','TTH','MTH','TF','W','S'), in roomselect ENUM('S326', 'S421', 'S422', 'S423', 'S425', 'S426', 'S428', 'S526', 'S527'))
BEGIN
	DECLARE classnum varchar(7);
    SELECT a.coursenumber INTO classnum FROM curricula a WHERE a.coursenumber = cnumber;
    IF EXISTS (SELECT * FROM classes_available WHERE (time_s BETWEEN time_start AND time_finish OR time_f BETWEEN time_start 
		AND time_finish) AND daysIn = days AND roomselect = room) THEN
		SIGNAL sqlstate '23400'
			SET message_text = 'Subject conflict!';
	ELSEIF (cnumber NOT IN (SELECT coursenumber FROM curricula)) THEN
		SIGNAL sqlstate '23500'
			SET message_text = 'Subject not found!';
	ELSE
		INSERT INTO classes_available (classcode, coursenumber, time_start, time_finish, days, room) values (ccode, classnum, time_s, time_f, daysIn, roomselect);        
		
END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `add_instructor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_instructor`(IN inst_last VARCHAR(45), inst_first VARCHAR(45), status ENUM('Contractual', 'Regular', 'Provisional', 'Part-Time'))
BEGIN
	INSERT INTO instructors (inst_lname, inst_fname, department, status) VALUES (inst_last, inst_first, status);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `assign_instructor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `assign_instructor`(IN classc VARCHAR(7), IN instructor_name VARCHAR(150))
BEGIN
	DECLARE ins_id INT(11);
    DECLARE temp_unit int(1);

    IF instructor_name NOT IN (SELECT inst_lname FROM instructors) THEN
		SIGNAL sqlstate '56000'
			SET message_text = 'Instructor NOT IN database!';
    ELSE
		
		SELECT a.instruct_id INTO ins_id FROM instructors a WHERE a.inst_lname = instructor_name;
        SELECT a.teachunits INTO temp_unit FROM curricula a JOIN classes_available b ON a.coursenumber = b.coursenumber WHERE b.classcode = classc;
        UPDATE classes_available
		SET inst_id = ins_id
		WHERE classcode = classc;
        
        UPDATE instructors
        SET inst_units = inst_units + temp_unit
        WHERE inst_lname = instructor_name;
        
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-09 18:34:32
